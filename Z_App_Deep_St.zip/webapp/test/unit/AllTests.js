sap.ui.define([
	"Z_App_Deep_St/Z_App_Deep_St/test/unit/controller/V_Detail.controller"
], function () {
	"use strict";
});